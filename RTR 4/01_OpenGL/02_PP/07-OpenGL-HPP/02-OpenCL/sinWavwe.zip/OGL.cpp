// Header Files
#include<Windows.h>

#include<stdlib.h> //For exit() 
#include<stdio.h>  //For File IO
#include"OGL.h" //For Icon Resource
#include"vmath.h"
using namespace vmath;


//include header file here
#include<GL/glew.h> // THIS MUST BE BEFORE gl.h
#include<GL/gl.h>

#include<CL/opencl.h>

//OpenCL Header File
//macro definations

#define WIN_WIDTH 800
#define WIN_HIGHT 600 

//openGL libraries
#pragma comment(lib,"glew32.lib")
#pragma comment(lib,"openGL32.lib")
#pragma comment(lib,"opencl.lib")
// Global Function Declarations

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);

//Global variable declarations

BOOL gbActiveWindow = FALSE;
BOOL gbFullScreen = FALSE;
FILE* gpFile = NULL;
HWND gHwnd = NULL;
HDC gHdc = NULL;
HGLRC ghrc = NULL;

//Programable pipeline related global variables
GLuint shaderProgramObject;

enum {
   olp_attribute_position=0,
   olp_attribute_color,
   olp_attribute_normal,
   olp_attribute_tecture0
};

GLuint vao;
GLuint vbo_position;
GLuint vbo_color;
GLuint mvpMatrixUniform;
mat4 perspectiveProjectionMatrix;

//Sign Wave Related Varibales
#define meshWidth  512
#define meshHeight 512

float pos[meshWidth][meshHeight][4];
float animationTime = 0.0;

#define MYARRAYSIZE meshWidth * meshHeight * 4

//OpenCL Related Variables
cl_platform_id oclPlatformID;
cl_int oclResult;
cl_mem graphicsResource = NULL;
cl_context oclContext;
cl_command_queue oclCommandQueue;
cl_program oclProgram;
cl_kernel oclKernel;
cl_device_id* oclDeviceIDs = NULL;
cl_device_id oclDeviceID;

GLuint vbo_GPU;
bool onGPU = false;


// Entry Point Function

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpszCmdLine, int iCmdShow) {

	//function declarations
	int initialize(void);
	void display(void);
	void update(void);
	void uninitialize(void);

	// variable declarations
	WNDCLASSEX wndclass;
	HWND hwnd;
	MSG msg;
	TCHAR szAppName[] = TEXT("MyWindow");
	BOOL bDone = FALSE;
	int iRetVal = 0;

	if (fopen_s(&gpFile, "Log.txt", "w") != 0) {
		MessageBox(NULL, TEXT("File Creation Failed.... exiting"), TEXT("Error"), MB_OK);
		exit(0);
	}
	else {
		fprintf(gpFile, "Log File Successfully Created\n");
	}

	// Initialization of WNDCLASSEX structure
	wndclass.cbSize = sizeof(WNDCLASSEX);
	wndclass.style = CS_HREDRAW | CS_VREDRAW | CS_OWNDC;
	wndclass.cbClsExtra = 0;
	wndclass.cbWndExtra = 0;
	wndclass.lpfnWndProc = WndProc;
	wndclass.hInstance = hInstance;
	wndclass.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	wndclass.hIcon = LoadIcon(hInstance, MAKEINTRESOURCE(MYICON));
	wndclass.hCursor = LoadCursor(NULL, IDC_ARROW);
	wndclass.lpszClassName = szAppName;
	wndclass.lpszMenuName = NULL;
	wndclass.hIconSm = LoadIcon(hInstance, MAKEINTRESOURCE(MYICON));

	// Register wndclass

	RegisterClassEx(&wndclass);

	// Create The Window
	hwnd = CreateWindowEx(WS_EX_APPWINDOW, szAppName,
		TEXT("Om Laxman Patil"),
		WS_OVERLAPPEDWINDOW | WS_CLIPCHILDREN | WS_CLIPSIBLINGS | WS_VISIBLE,
		(GetSystemMetrics(SM_CXSCREEN) - WIN_WIDTH) / 2,
		(GetSystemMetrics(SM_CYSCREEN) - WIN_HIGHT) / 2,
		WIN_WIDTH,
		WIN_HIGHT,
		NULL,
		NULL,
		hInstance,
		NULL
	);

	gHwnd = hwnd;

	//initialize
	iRetVal = initialize();
	if (iRetVal == -1) {
		fprintf(gpFile, "Choose Pixcel Format failed\n ");
		uninitialize();
	}
	if (iRetVal == -2) {
		fprintf(gpFile, "Set Pixcel Format failed\n ");
		uninitialize();
	}
	if (iRetVal == -3) {
		fprintf(gpFile, " Create OpenGL context failed\n ");
		uninitialize();
	}

	if (iRetVal == -4) {
		fprintf(gpFile, " Making OpenGL context current context failed\n ");
		uninitialize();
	}

	if (iRetVal == -5) {
		fprintf(gpFile, " glew initialization failed\n ");
		uninitialize();
	}
	// Show Window
	ShowWindow(hwnd, iCmdShow);

	// Forgrounding and focusing the window
	SetForegroundWindow(hwnd);
	SetFocus(hwnd);

	//Game Loop
	while (bDone == FALSE) {
		if (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
		{
			if (msg.message == WM_QUIT)
				bDone = TRUE;
			else {
				TranslateMessage(&msg);
				DispatchMessage(&msg);
			}
		}
		else {
			if (gbActiveWindow == TRUE)
			{
				//Render the Scene
				display();
				//upadate the Scene
				update();

			}
		}
	}

	uninitialize();
	return ((int)msg.wParam);

}

// CALLBACK FUNCTION
LRESULT CALLBACK WndProc(HWND hwnd, UINT imsg, WPARAM wParam, LPARAM lParam) {

	//function declarations
	void toggleFullScreen(void);
	void resize(int, int);
	void uninitialize(void);
	// code
	switch (imsg) {
	case WM_ERASEBKGND:
		return 0;
	case WM_CHAR:
		switch (wParam)
		{
		case 'c':
		case 'C':
			onGPU = false;
			break;
		case 'g':
		case 'G':
			onGPU = true;
			break;
		case 'F':
		case 'f':
			toggleFullScreen();
			break;
		default:
			break;
		}
		break;
	case WM_KEYDOWN:
		switch (wParam)
		{
		case 27:
			DestroyWindow(hwnd);
			break;
		default:
			break;
		}
		break;
	case WM_SETFOCUS:
		gbActiveWindow = TRUE;
		break;
	case WM_KILLFOCUS:
		gbActiveWindow = FALSE;
		break;
	case WM_SIZE:
		resize(LOWORD(lParam), HIWORD(lParam));
		break;
	case WM_CLOSE:
		DestroyWindow(hwnd);
		break;
	case WM_DESTROY:

		PostQuitMessage(0);
		break;
	default:
		break;
	}
	return (DefWindowProc(hwnd, imsg, wParam, lParam));
}

void toggleFullScreen() {

	//variable declarations
	static DWORD dwStyle;
	static WINDOWPLACEMENT wp;
	MONITORINFO mi;

	//code
	wp.length = sizeof(WINDOWPLACEMENT);

	if (gbFullScreen == FALSE) {
		dwStyle = GetWindowLong(gHwnd, GWL_STYLE);
		if (dwStyle & WS_OVERLAPPEDWINDOW) {
			mi.cbSize = sizeof(MONITORINFO);

			if (GetWindowPlacement(gHwnd, &wp) && GetMonitorInfo(MonitorFromWindow(gHwnd, MONITORINFOF_PRIMARY), &mi)) {
				SetWindowLong(gHwnd, GWL_STYLE, dwStyle & (~WS_OVERLAPPEDWINDOW));
				SetWindowPos(gHwnd, HWND_TOP, mi.rcMonitor.left, mi.rcMonitor.top, (mi.rcMonitor.right - mi.rcMonitor.left), (mi.rcMonitor.bottom - mi.rcMonitor.top), SWP_NOZORDER | SWP_FRAMECHANGED);
			}
			ShowCursor(FALSE);
			gbFullScreen = TRUE;
		}
	}
	else {

		SetWindowLong(gHwnd, GWL_STYLE, dwStyle | WS_OVERLAPPEDWINDOW);
		SetWindowPlacement(gHwnd, &wp);
		SetWindowPos(gHwnd, HWND_TOP, 0, 0, 0, 0, SWP_NOZORDER | SWP_FRAMECHANGED | SWP_NOMOVE | SWP_NOSIZE | SWP_NOOWNERZORDER);

		ShowCursor(TRUE);
		gbFullScreen = FALSE;
	}

}

int initialize(void) {

	//function declarations
	void resize(int, int);
	void uninitialize(void);
	void printGLInfo(void);
	
	//variable declarations
	PIXELFORMATDESCRIPTOR pfd;
	int iPixelFormatIndex = 0;

	//code
	ZeroMemory(&pfd, sizeof(PIXELFORMATDESCRIPTOR));
	pfd.nSize = sizeof(PIXELFORMATDESCRIPTOR);
	pfd.nVersion = 1;
	pfd.dwFlags = PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER;
	pfd.iPixelType = PFD_TYPE_RGBA;
	pfd.cDepthBits = 32; //Change For depth 24 also can be done
	pfd.cColorBits = 32;
	pfd.cRedBits = 8;
	pfd.cGreenBits = 8;
	pfd.cBlueBits = 8;
	pfd.cAlphaBits = 8;

	//GetDC
	gHdc = GetDC(gHwnd);
	//choose pixel format
	iPixelFormatIndex = ChoosePixelFormat(gHdc, &pfd);
	if (iPixelFormatIndex == 0)
		return -1;

	//Set The chosen pixel format
	if (SetPixelFormat(gHdc, iPixelFormatIndex, &pfd) == FALSE) {
		return -2;
	}
	//Create OpenGL rendering Context
	ghrc = wglCreateContext(gHdc);
	if (ghrc == NULL)
		return -3;

	//make the rendering as current context.
	if (wglMakeCurrent(gHdc, ghrc) == FALSE)
		return -4;


	//Here Starts openGl code

	//glew initialization
	if (glewInit() != GLEW_OK)
		return -5;

	//OpenCL initialization
	// 
	// Step 1
	//Get Platform ID 
	
	oclResult =clGetPlatformIDs(1, &oclPlatformID, NULL);
	if (oclResult != CL_SUCCESS)
	{
		fprintf(gpFile,"clGetPlatformIDs() Failed : %d\n", oclResult);
		uninitialize();
		exit(EXIT_FAILURE);
	}

	//Get GPU Device ID
	// Step 2 
	//Sub-Step 1
	//Get Total GPU device Count
	unsigned int devCount;
	oclResult = clGetDeviceIDs(oclPlatformID, CL_DEVICE_TYPE_GPU, 0, NULL, &devCount);
	if (oclResult != CL_SUCCESS)
	{
		fprintf(gpFile, "clGetDeviceIDs() Failed To Get Device Count : %d\n", oclResult);
		uninitialize();
		exit(EXIT_FAILURE);
	}
	else if (devCount == 0) {
		fprintf(gpFile, "GPU Device Count is 0 : %d\n", oclResult);
		uninitialize();
		exit(EXIT_FAILURE);
	}
	

	//Sub-Step 2
	//Create Memory For the Array of DeviceIDs for devCount
	oclDeviceIDs = (cl_device_id*)malloc(sizeof(cl_device_id) * devCount);
	if (oclDeviceIDs == NULL) {
		fprintf(gpFile, "Malloc() Failed for oclDeviceIDs");
		uninitialize();
		exit(EXIT_FAILURE);
	}
	//Sub-Step 3 
	//Fill the array of Device ID
	oclResult = clGetDeviceIDs(oclPlatformID, CL_DEVICE_TYPE_GPU, devCount,oclDeviceIDs,NULL);
	if (oclResult != CL_SUCCESS)
	{
		fprintf(gpFile, "clGetDeviceIDs() Failed : %d\n", oclResult);
		uninitialize();
		exit(EXIT_FAILURE);
	}

	//Sub-Step 4 
	//Get First ID
	oclDeviceID = oclDeviceIDs[0];
	
	//Sub-Step 5
	//Free Malloced Memory
	free(oclDeviceIDs);
	oclDeviceIDs = NULL;


	// Step 3
	//Create The OpenCL Context For Selected OpenCL Device
	//Sub-Step 1
	//Create Context Properties array
	cl_context_properties oclContextProperties[] =
	{
		CL_GL_CONTEXT_KHR,(cl_context_properties)wglGetCurrentContext(),
		CL_WGL_HDC_KHR,(cl_context_properties)wglGetCurrentDC(),
		CL_CONTEXT_PLATFORM,(cl_context_properties)oclPlatformID,
		0
	};

	//Sub-Step 1
	//Create The actual OpenCL Context
	oclContext = clCreateContext(oclContextProperties, 1, &oclDeviceID, NULL, NULL, &oclResult);
	if (oclResult != CL_SUCCESS)
	{
		fprintf(gpFile, "clCreateContext() Failed : %d\n", oclResult);
		uninitialize();
		exit(EXIT_FAILURE);
	}

	//Step 4 
	//Create Command Queue
	//clCreateCommandQueueWithProperties
	oclCommandQueue = clCreateCommandQueue(oclContext,oclDeviceID, 0, &oclResult);
	if (oclResult != CL_SUCCESS)
	{
		fprintf(gpFile, "clCreateCommandQueue() Failed : %d\n", oclResult);
		uninitialize();
		exit(EXIT_FAILURE);
	}

	//Step 5 
	//Create OpenCL Program From OpenCL Kernel Source Code
	//Sub-Step 1
	//Write OpenCL Kernel Source Code
	// OpenCL kernel
	const char* oclSourceCode =
		"__kernel void sinWaveKernel(__global float4 * position, unsigned int width, unsigned height, float time) { " \
		"unsigned int i = get_global_id(0) " \
		"unsigned int j = get_global_id(1) " \
		"float u = float(i) / float(width);" \
		"float v = float(j) / float(height);" \
		"u = u * 2.0f - 1.0f;" \
		"v = v * 2.0f - 1.0f; " \
		"float frequency = 4.0f; " \
		"float w = sin(u * frequency + time) * cos(v * frequency + time) * 0.5f; " \
		"position[j * width + i] = (float4)(u, w, v, 1.0f);" \
		"}";
	
	//Sub-Step 2
	//Create Actual openCL Program form above Source Code
	oclProgram = clCreateProgramWithSource(oclContext, 1, (const char**)&oclSourceCode, NULL, &oclResult);
	if (oclResult != CL_SUCCESS)
	{
		fprintf(gpFile, "clCreateProgramWithSource() Failed : %d\n", oclResult);
		uninitialize();
		exit(EXIT_FAILURE);
	}

	//Step 6
	//Build Program
	oclResult = clBuildProgram(oclProgram,0,NULL,NULL,NULL, NULL);
	if(oclResult != CL_SUCCESS)
	{
		fprintf(gpFile, "clBuildProgram() Failed : %d \n", oclResult);
		size_t len;
		char buffer[2048];
		oclResult = clGetProgramBuildInfo(oclProgram, oclDeviceID, CL_PROGRAM_BUILD_LOG, sizeof(buffer), buffer, &len);
		if (oclResult != CL_SUCCESS)
		{
			fprintf(gpFile, "clGetProgramBuildInfo Failed \n");
			uninitialize();
			exit(EXIT_FAILURE);

		}
		fprintf(gpFile,"Program Build Log : %s\n", buffer);
		uninitialize();
		exit(EXIT_FAILURE);
	}

	//Step 7
	//Create OpenCL Kernel
	oclKernel = clCreateKernel(oclProgram, "sinWaveKernel", &oclResult);
	if (oclResult != CL_SUCCESS)
	{
		fprintf(gpFile, "clCreateKernel Failed \n");
		uninitialize();
		exit(EXIT_FAILURE);

	}

	//printGLInfo();
	
	//vertex shader
	const GLchar* vertexShaderSourceCode =
		"#version 460 core" \
		"\n" \
		"in vec4 a_position;" \
		"in vec4 a_color;" \
		"uniform mat4 u_mvpMatrix;" \
		"void main(void)" \
		"{" \
		"gl_Position = u_mvpMatrix * a_position;" \
		"}";

	GLuint vertexShaderObject = glCreateShader(GL_VERTEX_SHADER);
	glShaderSource(vertexShaderObject, 1, (const GLchar**)&vertexShaderSourceCode, NULL);
	glCompileShader(vertexShaderObject);
	GLint status;
	GLint infoLogLength;
	char* log = NULL;

	glGetShaderiv(vertexShaderObject, GL_COMPILE_STATUS, &status);
	if (status == GL_FALSE) {
		glGetShaderiv(vertexShaderObject, GL_INFO_LOG_LENGTH, &infoLogLength);
		
		if (infoLogLength > 0) {
			log = (char*)malloc(infoLogLength);
			if (log != NULL) {
				GLsizei written;
				glGetShaderInfoLog(vertexShaderObject, infoLogLength, &written, log);
				fprintf(gpFile, "********VERTEX SHADER COMPILATION LOG********\n");
				fprintf(gpFile, "%s\n", log);
				free(log);
				uninitialize();
			}
		}
	}

	//fragment shader
	const GLchar* fragmentShaderSourceCode =
		"#version 460 core" \
		"\n" \
		"out vec4 FragColor;" \
		"void main(void)" \
		"{" \
		"FragColor = vec4(1.0f,0.5f,0.0f,1.0f);" \
		"}";

	GLuint fragmentShaderObject = glCreateShader(GL_FRAGMENT_SHADER);
	glShaderSource(fragmentShaderObject, 1, (const GLchar**)&fragmentShaderSourceCode, NULL);
	glCompileShader(fragmentShaderObject);
	status = 0;
	infoLogLength = 0;
	log = NULL;
	glGetShaderiv(fragmentShaderObject, GL_COMPILE_STATUS, &status);
	if (status == GL_FALSE) {
		glGetShaderiv(fragmentShaderObject, GL_INFO_LOG_LENGTH, &infoLogLength);
		if (infoLogLength > 0) {
			log = (char*)malloc(infoLogLength);
			if (log != NULL) {
				GLsizei written;
				glGetShaderInfoLog(fragmentShaderObject, infoLogLength, &written, log);
				fprintf(gpFile, "********FRAGMENT SHADER COMPILATION LOG********\n");
				fprintf(gpFile, "%s\n", log);
				free(log);
				uninitialize();
			}
		}
	}

	//shader program object
	shaderProgramObject = glCreateProgram();
	glAttachShader(shaderProgramObject, vertexShaderObject);
	glAttachShader(shaderProgramObject, fragmentShaderObject);
	glBindAttribLocation(shaderProgramObject, olp_attribute_position, "a_position");
	glBindAttribLocation(shaderProgramObject, olp_attribute_color, "a_color");
	glLinkProgram(shaderProgramObject);
	mvpMatrixUniform = glGetUniformLocation(shaderProgramObject, "u_mvpMatrix");

	status = 0;
	infoLogLength = 0;
	log = NULL;
	glGetProgramiv(shaderProgramObject, GL_LINK_STATUS, &status);
	if (status == GL_FALSE) {
		glGetProgramiv(shaderProgramObject, GL_INFO_LOG_LENGTH, &infoLogLength);
		if (infoLogLength > 0) {
			log = (char*)malloc(infoLogLength);
			if (log != NULL) {
				GLsizei written;
				glGetProgramInfoLog(shaderProgramObject, infoLogLength, &written, log);
				fprintf(gpFile, "********SHADER PROGRAM LINK LOG********\n");
				fprintf(gpFile, "%s\n", log);
				free(log);
				uninitialize();
			}
		}
	}

	
	//declaration of vertex data arrays
	for (unsigned int i = 0; i < meshWidth; i++) {
		for(unsigned int j=0;j<meshHeight;j++){
			for (unsigned int k = 0; k < 4; k++) {
				pos[i][j][k] = 0.0f;
			}
		}
	}
	//vao and vbo realted 
	
	glGenVertexArrays(1, &vao);
	glBindVertexArray(vao);

	//vbo for position
	glGenBuffers(1, &vbo_position);
	glBindBuffer(GL_ARRAY_BUFFER, vbo_position);
	glBufferData(GL_ARRAY_BUFFER,MYARRAYSIZE*sizeof(float),NULL, GL_DYNAMIC_DRAW);
	glBindBuffer(GL_ARRAY_BUFFER, 0);

	//vbo for GPU position
	glGenBuffers(1, &vbo_GPU);
	glBindBuffer(GL_ARRAY_BUFFER, vbo_GPU);
	glBufferData(GL_ARRAY_BUFFER, MYARRAYSIZE * sizeof(float), NULL, GL_DYNAMIC_DRAW);
	glBindBuffer(GL_ARRAY_BUFFER, 0);

	glBindVertexArray(0);
	 

	//Create OpenCL OpenGL InterOprability Resource
	graphicsResource = clCreateFromGLBuffer(oclContext, CL_MEM_WRITE_ONLY, vbo_GPU, &oclResult);
	if (oclResult != CL_SUCCESS)
	{
		fprintf(gpFile, "clCreateFromGLBuffer() Failed \n");
		uninitialize();
		exit(EXIT_FAILURE);

	}

	//Depth Related Changes
	glClearDepth(1.0f);
	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LEQUAL);

	//clearScreen using Blue color
	glClearColor(0.0f, 0.0f, 0.1f, 0.0f);

	perspectiveProjectionMatrix = mat4::identity();

	//warmup resize call
	resize(WIN_WIDTH, WIN_HIGHT);

	return 0;
}

void printGLInfo(void) {
     
	//Local variable declarations
	GLint numExtension=0;
	//code
	fprintf(gpFile, "OpenGL Vendor : %s\n",glGetString(GL_VENDOR));
	fprintf(gpFile, "OpenGL Rendrer : %s\n", glGetString(GL_RENDERER));
	fprintf(gpFile, "OpenGL Version : %s\n", glGetString(GL_VERSION));
	fprintf(gpFile, "OpenGL GLSL Version : %s\n", glGetString(GL_SHADING_LANGUAGE_VERSION));

	glGetIntegerv(GL_NUM_EXTENSIONS, &numExtension);
	fprintf(gpFile, "Number of Supported Extension : %d \n",numExtension);

	for (int i = 0; i < numExtension; i++) {
		fprintf(gpFile, "%s\n", glGetStringi(GL_EXTENSIONS,i));
	}

}

void resize(int width, int hight) {

	//code
	if (hight == 0)
		hight = 1; //To avoid divided by 0 exception 

	glViewport(0, 0, (GLsizei)width, (GLsizei)hight);

	

	perspectiveProjectionMatrix = vmath::perspective(45.0f, (GLfloat)width / (GLfloat)hight, 0.1f, 100.0f);


}

void display(void) {

	//function declarations
	void sinWave(unsigned int, unsigned int, float);
	void uninitialize(void);

	
	//code
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	//Use the shader Program object
	glUseProgram(shaderProgramObject);

	//Transformations
	mat4 translationMatrix = mat4::identity();
	mat4 modelViewMatrix = mat4::identity();
	mat4 modelViewProjectionMatrix = mat4::identity();
	
	translationMatrix = translate(0.0f, 0.0f, -3.0f);
	//modelViewMatrix = translationMatrix;
	modelViewProjectionMatrix = perspectiveProjectionMatrix * modelViewMatrix;


	glUniformMatrix4fv(mvpMatrixUniform, 1, GL_FALSE, modelViewProjectionMatrix);
	if (onGPU == true) {
			
		unsigned int width = meshWidth;
		unsigned int height = meshHeight;
			//Set OpenCL Kernel Parameters
			//passing 0th Parameter
			oclResult = clSetKernelArg(oclKernel, 0, sizeof(cl_mem), (void*)&graphicsResource);
			if (oclResult != CL_SUCCESS) {
				printf("clSetKernelArg() Failed For 0th parameter : %d\n", oclResult);
				uninitialize();
				exit(EXIT_FAILURE);
			}
			//passing 1st Parameter
			oclResult = clSetKernelArg(oclKernel,1, sizeof(unsigned int), (void*)&width);
			if (oclResult != CL_SUCCESS) {
				printf("clSetKernelArg() Failed For 1st Argument : %d\n", oclResult);
				uninitialize();
				exit(EXIT_FAILURE);
			}

			//passing 2nd Parameter
			oclResult = clSetKernelArg(oclKernel, 2, sizeof(unsigned int), (void*)&height);
			if (oclResult != CL_SUCCESS) {
				fprintf(gpFile,"clSetKernelArg() Failed For 2nd Argument : %d\n", oclResult);
				uninitialize();
				exit(EXIT_FAILURE);
			}

			//passing 3rd Parameter
			oclResult = clSetKernelArg(oclKernel, 3, sizeof(float), (void*)&animationTime);
			if (oclResult != CL_SUCCESS) {
				fprintf(gpFile,"clSetKernelArg() Failed For 3rd Argument : %d\n", oclResult);
				uninitialize();
				exit(EXIT_FAILURE);
			}

			//Enqueue graphics resource into the command queue
			oclResult = clEnqueueAcquireGLObjects(oclCommandQueue,1,&graphicsResource,0,NULL,NULL);
			if (oclResult != CL_SUCCESS) {
				fprintf(gpFile,"clEnqueueAcquireGLObjects() Failed For 3rd Argument : %d\n", oclResult);
				uninitialize();
				exit(EXIT_FAILURE);
			}

			size_t global_Work_size[2] = {width,height};

			oclResult = clEnqueueNDRangeKernel(oclCommandQueue, oclKernel, 2, NULL, global_Work_size, NULL, 0, NULL, NULL);
			if (oclResult != CL_SUCCESS) {
				fprintf(gpFile,"clEnqueueNDRangeKernel() Failed : %d\n", oclResult);
				uninitialize();
				exit(EXIT_FAILURE);
			}

			oclResult = clEnqueueReleaseGLObjects(oclCommandQueue, 1, &graphicsResource, 0, NULL, NULL);
			if (oclResult != CL_SUCCESS) {
				fprintf(gpFile, "clEnqueueReleaseGLObjects() Failed For 3rd Argument : %d\n", oclResult);
				uninitialize();
				exit(EXIT_FAILURE);
			}


			//finish OpenCl Command queue
			clFinish(oclCommandQueue);
			glBindBuffer(GL_ARRAY_BUFFER, vbo_GPU);
			//glBufferData(GL_ARRAY_BUFFER, MYARRAYSIZE * sizeof(float), pPos, GL_DYNAMIC_DRAW);
	}
	else{
			//cpu related code 
			sinWave(meshWidth, meshHeight, animationTime);
			glBindBuffer(GL_ARRAY_BUFFER, vbo_position);
			glBufferData(GL_ARRAY_BUFFER, MYARRAYSIZE * sizeof(float), pos, GL_DYNAMIC_DRAW);
	}
		glVertexAttribPointer(olp_attribute_position, 4, GL_FLOAT, GL_FALSE, 0, NULL);
		glEnableVertexAttribArray(olp_attribute_position);
		glDrawArrays(GL_POINTS, 0, meshWidth * meshHeight);
		glBindBuffer(GL_ARRAY_BUFFER, 0);
		glBindVertexArray(0);


		//unuse the shader program object
		glUseProgram(0);

		animationTime += 0.01f;
		SwapBuffers(gHdc);
	}

void sinWave(unsigned int width, unsigned int height, float time) {

	//code
	
	for (unsigned int i = 0; i < width; i++) {
		for (unsigned int j = 0; j < height; j++) {
			for (unsigned int k = 0; k < 4; k++) {
				float u = float(i) / float(width);
				float v = float(j) / float(height);

				u = u * 2.0f - 1.0f;
				v = v * 2.0f - 1.0f;

				float frequency = 4.0f;
				float w = sinf(u * frequency + time) * cosf(v * frequency + time) * 0.5f; //(0.5 for applitude adjustment)
				
				if (k == 0) {
					pos[i][j][k] = u;
				}
				if (k == 1) {
					pos[i][j][k] = w;
				}
				if (k == 2) {
					pos[i][j][k] = v;
				}
				if (k == 3) {
					pos[i][j][k] = 1.0f;
				}
			}
		}
	}

}


void update(void) {

	//code

}

void uninitialize(void) {

	//function declarations
	void toggleFullScreen(void);
	//code
	if (gbFullScreen) {
		toggleFullScreen();
	}

	if (vbo_GPU) {

		if (graphicsResource) {
			clReleaseMemObject(graphicsResource);
		}
		glDeleteBuffers(1, &vbo_GPU);
		vbo_GPU = 0;
	}
		if (oclKernel) {
			clReleaseKernel(oclKernel);
			oclKernel = NULL;
		}
		if (oclProgram) {
			clReleaseProgram(oclProgram);
			oclProgram = NULL;
		}

		if (oclCommandQueue) {
			clReleaseCommandQueue(oclCommandQueue);
			oclCommandQueue = NULL;
		}
		if (oclContext) {
			clReleaseContext(oclContext);
			oclContext = NULL;
		}

	//deletion and uninitalization
	

	if (vbo_position) {
		glDeleteBuffers(1, &vbo_position);
		vbo_position = 0;
	}
	if (vao) {
		glDeleteVertexArrays(1, &vao);
		vao = 0;
	}

	//shader uninitialization
	if (shaderProgramObject) {
		glUseProgram(shaderProgramObject);
		GLsizei numAttachedShaders;
		glGetProgramiv(shaderProgramObject,GL_ATTACHED_SHADERS, &numAttachedShaders);
		GLuint* shaderObjects = NULL;
		shaderObjects = (GLuint*)malloc(numAttachedShaders*sizeof(GLuint));
		if (shaderObjects != NULL) {
			//filling shaderObjects with attached shaders
			glGetAttachedShaders(shaderProgramObject, numAttachedShaders, &numAttachedShaders, shaderObjects);
			for (GLsizei i = 0; i < numAttachedShaders; i++) {
				glDetachShader(shaderProgramObject, shaderObjects[i]);
				glDeleteShader(shaderObjects[i]);
				shaderObjects[i] = 0;
			}
			free(shaderObjects);
			shaderObjects = NULL;  
		}

		glUseProgram(0);
		glDeleteProgram(shaderProgramObject);
		shaderProgramObject = 0;

	}

	if (wglGetCurrentContext() == ghrc) {
		wglMakeCurrent(NULL, NULL);
	}
	if (ghrc)
	{
		wglDeleteContext(ghrc);
		ghrc = NULL;
	}
	if (gHdc) {
		ReleaseDC(gHwnd, gHdc);
		gHdc = NULL;
	}
	if (gHwnd) {
		DestroyWindow(gHwnd);
		gHwnd = NULL;
	}
	if (gpFile) {
		fprintf(gpFile, "Log File Successfully Closed");
		fclose(gpFile);
		gpFile = NULL;
	}
}

