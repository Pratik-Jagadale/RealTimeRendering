#pragma once
#define MYICON 101

#define IDBITMAP_WOOD 501
#define IDBITMAP_LEAF 502

