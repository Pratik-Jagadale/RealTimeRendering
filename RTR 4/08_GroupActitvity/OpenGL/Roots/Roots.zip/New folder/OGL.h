#pragma once

#define MYICON 101
#define IDBITMAP_ROOT_TEXTURE 102
